import numpy as np

def gen_func(x):
#     return 2.5 * x - 0.3 + 10 * np.random.randn()
#     return 0.03 * x * x - 0.25 * x - 0.3 + 10 * np.random.randn()
#     return 0.004 * x**3 - 0.002 * x * x + 0.2 * x - 0.3 + 50 * np.random.randn()
    return (x - np.random.randint(-20, 20)) * np.random.rand()

x = 100 * (np.random.rand(100) - 0.5)

y = np.array([gen_func(x_val) for x_val in x])
np.save('unknown_data', np.c_[x, y])
